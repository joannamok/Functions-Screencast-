// Functions Screencast
//Function Invocation

function outptMsg(){
	console.log("Hello World");
}

function calcArea(){
	var width = 20;
	var height = 30;
	var area = width * height;
	console.log(area);
}

calcArea();
calcArea();
calcArea(); //invoces calcArea function