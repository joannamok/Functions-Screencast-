// Functions Screencast
//Arguments and Parameters	// How to set them up

calcArea(30, 20);

function calcArea(w, h) // w=30, h=20

function calcArea(){
	var area = w * h;
	console.log(area);
}