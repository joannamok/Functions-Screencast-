// Functions Screencast
//Arguments and Parameters	// Dog Years //using paremeters

function dogYears(age){
	var dogYears = age * 7;
	console.log("Sparky is" + dogYears + "years old.")
}

dogYears(4);
dogYears(5);
