// Functions Screencast
//Arguments and Parameters	// Dog Years //using paremeters

function dogYears(age){
	var dogYears = age * 7;
	console.log("Sparky is" + dogYears + "years old.")
}


//Using a var in place,not the right way
var age1 = 4;
dogYears(age1);
dogYears(5);
