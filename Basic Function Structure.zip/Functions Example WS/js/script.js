// Functions Screencast
//Basic Function Stucture

function outptMsg(){
	console.log("Hello World")
}

function calcArea(){
	var width = 20;
	var height = 30;
	var area = width * height;
	console.log(area);
}