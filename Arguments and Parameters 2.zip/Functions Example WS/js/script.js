// Functions Screencast
//Arguments and Parameters	// Dog Years

function dogYears(){
	var age =4;
	var dogYears = age * 7;
	console.log("Sparky is" + dogYears + "years old.")
}

dogYears();
dogYears();