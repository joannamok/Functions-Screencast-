// Functions Screencast
//Anonymous Functions (closures)


var calcArea = function(width, height){ //invoking
	//code that runs function
	var area = width * height; //defining 
	return area;
}

var a = calcArea(20, 30);

console.log(a);