// Functions Screencast
//Function vs Procedure

//this is a function (functions actually return values)
function calcAreaF(width, height){
	var area + width * height;
	return area;
}

//This is a Procedure
function calcAreaP(width,height){
	var area = width * height;
	console.log(area); //no return
}